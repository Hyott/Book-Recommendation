g1.b
